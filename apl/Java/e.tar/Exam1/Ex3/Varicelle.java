import java.util.*;
import javax.swing.*;
import java.awt.*;

public class Varicelle {
    public static void main(String []args){
	int nbCercle=Integer.parseInt(args[0]);
	Couleur coul =new Couleur(nbCercle);

// int nbP = args.length;  
// for (int i = 0; i < nbP; i++) {  
//     System.out.println(args[i]); 
//}
    }
}