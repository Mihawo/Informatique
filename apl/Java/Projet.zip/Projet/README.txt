Instructions:

$ javac *.java
$ java Principale

Principale: C'est l'accueil, contient 3 boutons pour jouer sois en 9x9, 13x13 ou 19x19.

MainPanel: Contient le terrain de jeu.

